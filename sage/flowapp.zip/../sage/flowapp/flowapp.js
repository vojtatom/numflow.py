// SAGE2 is available for use under the SAGE2 Software License
//
// University of Illinois at Chicago's Electronic Visualization Laboratory (EVL)
// and University of Hawai'i at Manoa's Laboratory for Advanced Visualization and
// Applications (LAVA)
//
// See full text, terms and conditions in the LICENSE.txt included file
//
// Copyright (c) 2014


var plasma_flow = SAGE2_App.extend({
	init: function(data) {
		this.SAGE2Init("canvas", data);	
		this.resizeEvents = "continuous";
		this.maxFPS = 60;
		this.loaded = false;

		//init gl stuff
		//this.updateDescriptionBox();
		//this.fileLoad();

		var _this = this;
		this.element.addEventListener("webglcontextlost", function(event) {
				console.log("WebGL Context Lost");
				console.log(event);
				event.preventDefault();
				_this.loaded = false;
			}, false);

		this.element.addEventListener("webglcontextrestored", function(event) {
				console.log("WebGL Context Restored");
				console.log(event);
				_this.loaded = true;
			}, false);

		//this.controls.addButton({type: "default", position: 1, label: "reload", identifier: "reload"});
		//this.controls.addButton({type: "default", position: 2, label: "mode", identifier: "toggle"});
		//this.controls.addButton({type: "default", position: 3, label: "spl--", identifier: "up"});
		//this.controls.addButton({type: "default", position: 4, label: "spl++", identifier: "down"});
		

		this.controls.finishedAddingControls();
	},

	/**
	* Load file resources for webgl
	* @method fileLoad
	*/
	initFlowApp: function() {
        let canvas = this.element;
        let app = new FlowApp(canvas);

        Shader.dir = this.resrcPath + '/shaders/';

        //getting files from local fs
        let getFile = function(filename) {
            return new Promise(function(resolve, reject) {
                readFile(filename, function(err, data){
                    if (err) 
                        reject(err); 
                    else 
                        resolve(data);
                });
            });
        };

        //adjust DataManager fiel loading
        DataManager.files = function(options){
            let requests = [];

            for (let file of options.files) {
                requests.push(getFile(file));
            }
    
            Promise.all(requests).then(
                options.success,
                options.fail,
            );
        };


        app.init('test-key');
        app.graphics.resize(this.element.width, this.element.height);
        
        this.app = app;
        this.loaded = true;
	},

	/**
	 * Load the app from a previous state
	 * @method load
	 * @param state object to initialize or restore the app
	 * @param date time from the server
	 */
	load: function(state, date) {
		/* TODO */
	},

	/**
	 * Perform on draw loop
	 *
	 * @method draw
	 * @param date time from the server
	 */
	draw: function(date) {
		if (this.loaded === false || this.loaded === undefined)
			return;

		this.app.render();
	},

	/**
	 * Resize viewport webgl context
	 *
	 * @method resize
	 * @param date time from the server
	 */
	resize: function(date) {
		this.loaded = false;
		this.app.resize(this.element.width, this.element.height);
		this.loaded = true;
	},

	/**
	 * Handles event processing for the app
	 *
	 * @method event
	 * @param eventType event type
	 * @param position x and y positions
	 * @param user_id data user data from who triggered the event
	 * @param data other event data
	 * @param date current time from the server
	 */

	event: function(eventType, position, user_id, data, date) {
		if (eventType === "specialKey" && data.state === "down") {
            this.app.interface.onKeyDown(data.code);
        }

		if (eventType === "specialKey" && data.state === "up") {
			this.app.interface.onKeyUp(data.code);
		}

		if (eventType === "pointerScroll") {
			if (this.mouse.layer && this.app.getMode() === 'layer mode')
				this.app.moveLayer(data.wheelDelta);
			else
				this.app.zoom(data.wheelDelta);		
		}

		if (eventType === "pointerPress" && data.button === "left") {    
            this.app.interface.onMouseDown(position.x, position.y);
		}

		if (eventType === "pointerRelease" && data.button === "left") {
			this.app.interface.onMouseUp(position.x, position.y);
		}

		if (eventType === "pointerMove") {
			app.interface.onMouseMove(position.x, position.y);
		}
	},
});