'use strict';
 

class DataManager {

    static requestFrequent(options) {
           if (DataManager.changeTimer !== false)
               clearTimeout(DataManager.changeTimer);
   
               DataManager.changeTimer = setTimeout(() => {
               return DataManager.request(options);
           }, 300);
       }

    static request(options) {
        if (!('method' in options))
            options['method'] = 'POST';

        let request = new XMLHttpRequest();
        let token = Cookies.get('csrftoken');

        request.open(options.method, options.url, true);
        request.setRequestHeader('X-CSRFTOKEN', token);
        request.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

        request.onload = function () {
            if (request.status === 200) {
                let response = request.responseText;
                if ('decode' in options && options.decode)
                    response = JSON.parse(response);
                options.success(response, request.responseURL);
            } else {
                options.fail(request.responseText);
            }
        };

        if ('headers' in options)
            request.setRequestHeader(...options.headers);

        if ('data' in options) {
            let data = JSON.stringify(options.data);
            request.setRequestHeader('Content-type', 'application/json');
            request.send(data);
        } else if ('form' in options) {
            request.send(options.form);
        } else {
            request.send();
        }
    }

    static upload(options) {
        let request = new XMLHttpRequest();
        let token = Cookies.get('csrftoken');

        request.open('POST', options.url, true);
        request.setRequestHeader('X-CSRFTOKEN', token);
        request.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

        request.onload = function () {
            if (request.status === 200) {
                options.success(request.responseText, request.responseURL);
            } else {
                options.fail(request.responseText);
            }
        };

        request.send(options.data);
    }

    static files(options) {
        let requests = [];

        for (let file of options.files) {
            requests.push(DataManager.getPromise(file));
        }

        Promise.all(requests).then(
            options.success,
            options.fail,
        );
    }

    static getPromise(url) {
        return new Promise(function (resolve, reject) {
            var request = new XMLHttpRequest();
            request.open('GET', url);

            request.onload = function () {
                if (request.status == 200) {
                    resolve(request.response);
                }
                else {
                    reject(Error(request.statusText));
                }
            };

            request.onerror = function () {
                reject(Error("Network Error"));
            };

            request.send();
        });
    }

    static getIcon(url) {
        return '/static/visual/canvas/icons/' + url;
    }
}
 

class ShaderType {
    static get vertex() {
        return 0;
    }
    
    static get fragement() {
        return 1;
    }
} 

class Shader {
    constructor(gl, code, type){
        this.type = type;
        this.gl = gl;
        this.code = code;
        this.createShader();

    }

    createShader() {
        let type;
        if (this.type == Shader.type.vertex)
            type = this.gl.VERTEX_SHADER;
        else 
            type = this.gl.FRAGMENT_SHADER;

		this.shader = this.gl.createShader(type);
		this.gl.shaderSource(this.shader, this.code);

		this.gl.compileShader(this.shader);
		if (!this.gl.getShaderParameter(this.shader, this.gl.COMPILE_STATUS)) {
            console.error('ERROR compiling shader!', this.gl.getShaderInfoLog(this.shader));
            console.error(this.code);
			throw 'ERROR compiling shader!';
        }
    }
    
    static get type() {
        return ShaderType;
    }
} 

class Program {
    constructor(gl) {
        this.gl = gl;

        this.state = {
            init: false,
            attrs: false,
            unifs: false,
        }

        this.GLType = {
            float: this.gl.uniform1f,
            int: this.gl.uniform1i,
            
            vec2: this.gl.uniform2fv,
            vec3: this.gl.uniform3fv, 
            vec4: this.gl.uniform4fv,
            
            mat4: this.gl.uniformMatrix4fv,
        }

        this.uniforms = {};

        this.loaded = false;
    }

    init(vs, fs) {
        this.vs = new Shader(this.gl, vs, Shader.type.vertex);
        this.fs = new Shader(this.gl, fs, Shader.type.fragement);

        this.createProgram();
        this.update('init');
    }

    createProgram() {
		let program = this.gl.createProgram();

		this.gl.attachShader(program, this.vs.shader);
		this.gl.attachShader(program, this.fs.shader);

		this.gl.linkProgram(program);
		if (!this.gl.getProgramParameter(program, this.gl.LINK_STATUS)) {
			console.error('ERROR linking program!', this.gl.getProgramInfoLog(program));
		}

		this.gl.validateProgram(program);
		if (!this.gl.getProgramParameter(program, this.gl.VALIDATE_STATUS)) {
			console.error('ERROR validating program!', this.gl.getProgramInfoLog(program));
        }

        this.program = program;
    }
    
    setupAttributes(attr) {
        this.attributes = {};

        for(let key in attr){
            this.attributes[key] = this.gl.getAttribLocation(this.program, attr[key]);
        }

        this.update('attrs');
    }

    setupUniforms(unif) {

        for(let key in unif){
            this.uniforms[key] = {
                location: this.gl.getUniformLocation(this.program, unif[key].name),
                assignFunction: unif[key].type,
            } 
        }  
            
        this.update('unifs');
    }

    bindAttribute(set){
        //console.log(set);

        this.gl.enableVertexAttribArray(set.attribute);
        this.gl.vertexAttribPointer(set.attribute, set.size, this.gl.FLOAT, this.gl.FALSE, set.stride, set.offset);
        if ('divisor' in set){
            this.gl.vertexAttribDivisor(set.attribute, set.divisor);
        }
    }


    bindUniforms(options) {
        for(let key in this.uniforms){
            if (this.uniforms[key].assignFunction === this.GLType.mat4){
                //console.log(key, options[key]);
                this.uniforms[key].assignFunction.apply(this.gl, [this.uniforms[key].location, this.gl.FALSE, options[key]]);
            } else {
                //console.log(key, options[key]);
                this.uniforms[key].assignFunction.apply(this.gl, [this.uniforms[key].location, options[key]]);
            }
        }
    }

    commonUniforms() {
        this.setupUniforms({
            model: {
                name: 'mWorld',
                type: this.GLType.mat4,
            },
			view: {
                name: 'mView',
                type: this.GLType.mat4,   
            },
            proj: {
                name: 'mProj',
                type: this.GLType.mat4,
            },
        });
    }

    bind() {
        this.gl.useProgram(this.program);
    }

    unbind() {
        this.gl.useProgram(null);
    }

    update(key){
        this.state[key] = true;
        if (this.state.init && this.state.attrs && this.state.unifs)
            this.loaded = true;
    }
} 

class MethodProgram extends Program {
    commonUniforms() {
        super.commonUniforms();
        this.setupUniforms({
            //lights
            light: {
                name: 'light',
                type: this.GLType.vec3,
            },
            //colormap
            colorMapSize: {
                name: 'colorMapSize',
                type: this.GLType.int, 
            },
            colorMap0: {
                name: 'colorMap[0]',
                type: this.GLType.vec4,
            },
            colorMap1: {
                name: 'colorMap[1]',
                type: this.GLType.vec4,
            },
            colorMap2: {
                name: 'colorMap[2]',
                type: this.GLType.vec4,
            },
            colorMap3: {
                name: 'colorMap[3]',
                type: this.GLType.vec4,
            },
            colorMap4: {
                name: 'colorMap[4]',
                type: this.GLType.vec4,
            },

            //stats
            minSize: {
                name: 'minSize',
                type: this.GLType.float,
            },
            maxSize: {
                name: 'maxSize',
                type: this.GLType.float,   
            },
            medianSize: {
                name: 'medianSize',
                type: this.GLType.float,
            },
            meanSize: {
                name: 'meanSize',
                type: this.GLType.float,
            },
            stdSize: {
                name: 'stdSize',
                type: this.GLType.float,
            },

            //scale and shift
            scaleFactor: {
                name: 'scaleFactor',
                type: this.GLType.float,
            },
            shift: {
                name: 'shift',
                type: this.GLType.vec3,
            },

            //world settings
            light: {
                name: 'light',
                type: this.GLType.vec3,
            },

            //geometry
            brightness: {
                name: 'brightness',
                type: this.GLType.float,
            },

            appearance: {
                name: 'appearance',
                type: this.GLType.int,
            },

            mode: {
                name: 'mode',
                type: this.GLType.int,
            },
        });
    }
} 

class BoxProgram extends Program {
    constructor(gl) {
        super(gl);
        DataManager.files({
            files: [
                Shader.dir + 'box_vs.glsl',
                Shader.dir + 'box_fs.glsl',
            ],
            success: (f) => {
                    this.init(...f)
                    this.setup();
                },
            fail: (r) => { console.error(r); },
            });
    }

    setup(){
        this.setupAttributes({
            position: 'vertPosition',
        });

        this.commonUniforms();
    }

    bindAttrPosition(options) {
        this.gl.useProgram(this.program);
        this.bindAttribute({
            attribute: this.attributes.position,
            size: 3,
            stride: 3 * Float32Array.BYTES_PER_ELEMENT,
            offset: 0,
        });
        this.gl.useProgram(null);
    }
} 

class GlyphProgram extends MethodProgram {
    constructor(gl) {
        super(gl);
        DataManager.files({
            files: [
                Shader.dir + 'glyph_vs.glsl',
                Shader.dir + 'glyph_fs.glsl',
            ],
            success: (f) => {
                this.init(...f)
                this.setup();
            },
            fail: (r) => { console.error(r); },
        });
    }

    setup() {
        this.setupAttributes({
            position: 'vertPosition',
            normal: 'vertNormal',
            fieldPos: 'fieldPosition',
            fieldVal: 'fieldValue',
        });

        this.commonUniforms();
        this.setupUniforms({
            size: {
                name: 'size',
                type: this.GLType.float,
            }
        });
    }

    bindAttrFieldPosition() {
        this.gl.useProgram(this.program);
        this.bindAttribute({
            attribute: this.attributes.fieldPos,
            size: 3,
            stride: 3 * Float32Array.BYTES_PER_ELEMENT,
            offset: 0,
            divisor: 1,
        });
        this.gl.useProgram(null);
    }

    bindAttrFieldValue() {
        this.gl.useProgram(this.program);
        this.bindAttribute({
            attribute: this.attributes.fieldVal,
            size: 3,
            stride: 3 * Float32Array.BYTES_PER_ELEMENT,
            offset: 0,
            divisor: 1,
        });
        this.gl.useProgram(null);
    }

    bindAttrVertexPosition() {
        this.gl.useProgram(this.program);
        this.bindAttribute({
            attribute: this.attributes.position,
            size: 3,
            stride: 3 * Float32Array.BYTES_PER_ELEMENT,
            offset: 0,
        });
        this.gl.useProgram(null);
    }

    bindAttrVertexNormal() {
        this.gl.useProgram(this.program);
        this.bindAttribute({
            attribute: this.attributes.normal,
            size: 3,
            stride: 3 * Float32Array.BYTES_PER_ELEMENT,
            offset: 0,
        });
        this.gl.useProgram(null);
    }
} 

class StreamProgram extends MethodProgram {
    constructor(gl) {
        super(gl);
        DataManager.files({
            files: [
                Shader.dir + 'stream_vs.glsl',
                Shader.dir + 'stream_fs.glsl',
            ],
            success: (f) => {
                this.init(...f)
                this.setup();
            },
            fail: (r) => { console.error(r); },
        });

    }

    setup() {
        this.setupAttributes({
            position: 'vertPosition',
            normal: 'vertNormal',

            fieldPos0: 'fieldPosition0',
            fieldPos1: 'fieldPosition1',
            fieldPos2: 'fieldPosition2',
            fieldPos3: 'fieldPosition3',
            fieldVal0: 'fieldValue0',
            fieldVal1: 'fieldValue1',
            fieldVal2: 'fieldValue2',
            fieldVal3: 'fieldValue3',

            tLocal: 't_local',
            tGlobal: 't_global',
        });

        this.commonUniforms();
        this.setupUniforms({
            size: {
                name: 'size',
                type: this.GLType.float,
            },
            time: {
                name: 'time',
                type: this.GLType.vec2,
            },
            
        });
    }


    bindAttrBigBuffer() {
        this.gl.useProgram(this.program);
        let attrs = [
            {
                attribute: this.attributes.fieldPos0,
                stride: 28 * Float32Array.BYTES_PER_ELEMENT,
                offset: 0,
                size: 3,
                divisor: 1,
            },
            {
                attribute: this.attributes.fieldPos1,
                stride: 28 * Float32Array.BYTES_PER_ELEMENT,
                offset: 3 * Float32Array.BYTES_PER_ELEMENT,
                size: 3,
                divisor: 1,
            },
            {
                attribute: this.attributes.fieldPos2,
                stride: 28 * Float32Array.BYTES_PER_ELEMENT,
                offset: 6 * Float32Array.BYTES_PER_ELEMENT,
                size: 3,
                divisor: 1,
            },
            {
                attribute: this.attributes.fieldPos3,
                stride: 28 * Float32Array.BYTES_PER_ELEMENT,
                offset: 9 * Float32Array.BYTES_PER_ELEMENT,
                size: 3,
                divisor: 1,
            },
            {
                attribute: this.attributes.fieldVal0,
                stride: 28 * Float32Array.BYTES_PER_ELEMENT,
                offset: 12 * Float32Array.BYTES_PER_ELEMENT,
                size: 3,
                divisor: 1,
            },
            {
                attribute: this.attributes.fieldVal1,
                stride: 28 * Float32Array.BYTES_PER_ELEMENT,
                offset: 15 * Float32Array.BYTES_PER_ELEMENT,
                size: 3,
                divisor: 1,
            },
            {
                attribute: this.attributes.fieldVal2,
                stride: 28 * Float32Array.BYTES_PER_ELEMENT,
                offset: 18 * Float32Array.BYTES_PER_ELEMENT,
                size: 3,
                divisor: 1,
            },
            {
                attribute: this.attributes.fieldVal3,
                stride: 28 * Float32Array.BYTES_PER_ELEMENT,
                offset: 21 * Float32Array.BYTES_PER_ELEMENT,
                size: 3,
                divisor: 1,
            },
            {
                attribute: this.attributes.tGlobal,
                stride: 28 * Float32Array.BYTES_PER_ELEMENT,
                offset: 24 * Float32Array.BYTES_PER_ELEMENT,
                size: 4,
                divisor: 1,
            },
        ];

        for (let attr of attrs) {
            this.bindAttribute(attr);
        }

        this.gl.useProgram(null);
    }

    bindAttrPosition() {
        this.gl.useProgram(this.program);
        this.bindAttribute({
            attribute: this.attributes.position,
            size: 3,
            stride: 3 * Float32Array.BYTES_PER_ELEMENT,
            offfset: 0,
        });
        this.gl.useProgram(null);
    }

    bindAttrNormal() {
        this.gl.useProgram(this.program);
        this.bindAttribute({
            attribute: this.attributes.normal,
            size: 3,
            stride: 3 * Float32Array.BYTES_PER_ELEMENT,
            offfset: 0,
        });
        this.gl.useProgram(null);
    }

    bindAttrTime() {
        this.gl.useProgram(this.program);
        this.bindAttribute({
            attribute: this.attributes.tLocal,
            size: 1,
            stride: 1 * Float32Array.BYTES_PER_ELEMENT,
            offfset: 0,
        });
        this.gl.useProgram(null);
    }

} 

class TextProgram extends Program {
    constructor(gl) {
        super(gl);
        DataManager.files({
            files: [
                Shader.dir + 'text_vs.glsl',
                Shader.dir + 'text_fs.glsl',
            ],
            success: (f) => {
                this.init(...f)
                this.setup();
            },
            fail: (r) => { console.error(r); },
        });
    }

    setup() {
        this.setupAttributes({
            position: 'position',
            texcoord: 'texcoord',
        });

        this.commonUniforms();
        this.setupUniforms({
            texture: {
                name: 'texture',
                type: this.GLType.int,
            },
            labelSize: {
                name: 'labelSize',
                type: this.GLType.vec2,
            },
            screenSize: {
                name: 'screenSize',
                type: this.GLType.vec2,
            },
        });
    }


    bindAttrPosition() {
        this.gl.useProgram(this.program);
        this.bindAttribute({
            attribute: this.attributes.position,
            size: 3,
            stride: 3 * Float32Array.BYTES_PER_ELEMENT,
            offfset: 0,
        });
        this.gl.useProgram(null);
    }

    bindAttrTexcoord() {
        this.gl.useProgram(this.program);
        this.bindAttribute({
            attribute: this.attributes.texcoord,
            size: 2,
            stride: 2 * Float32Array.BYTES_PER_ELEMENT,
            offfset: 0,
        });        
        this.gl.useProgram(null);
    }
} 

class LayerProgram extends MethodProgram {
    constructor(gl) {
        super(gl);
        DataManager.files({
            files: [
                Shader.dir + 'layer_vs.glsl',
                Shader.dir + 'layer_fs.glsl',
            ],
            success: (f) => {
                this.init(...f)
                this.setup();
            },
            fail: (r) => { console.error(r); },
        });
    }

    setup() {
        this.setupAttributes({
            fieldPos: 'fieldPosition',
            fieldVal: 'fieldValue',
        });

        this.commonUniforms();
        this.setupUniforms({
            normal: {
                name: 'normal',
                type: this.GLType.vec3,
            },
            cameraPosition: {
                name: 'cameraPosition',
                type: this.GLType.vec3,
            }
        });
    }

    bindAttrPosition() {
        this.gl.useProgram(this.program);
        this.bindAttribute({
            attribute: this.attributes.fieldPos,
            size: 3,
            stride: 3 * Float32Array.BYTES_PER_ELEMENT,
            offset: 0,
        });
        this.gl.useProgram(null);
    }

    bindAttrValue() {
        this.gl.useProgram(this.program);
        this.bindAttribute({
            attribute: this.attributes.fieldVal,
            size: 3,
            stride: 3 * Float32Array.BYTES_PER_ELEMENT,
            offset: 0,
        });
        this.gl.useProgram(null);
    }
} 

class Appearance {
    static get solid() {
        return 1;
    }

    static get transparent() {
        return 0;
    }

    static encode(a) {
        return {
            transparent: 0,
            solid: 1,
        }[a];
    }

    static decode(a) {
        return ['transparent', 'solid'][a];
    }
}


class Scale {
    static get log() {
        return 0;
    }

    static get normal() {
        return 1;
    }

    static encode(a) {
        return {
            log: 0,
            normal: 1,
        }[a];
    }

    static decode(a) {
        return ['log', 'normal'][a];
    }
}

class CoordMode {
    static get xyz(){
        return 0;
    }

    static get x(){
        return 1;
    }

    static get y(){
        return 2;
    }

    static get z(){
        return 3;
    }

    static encode(a) {
        return {
            xyz: 0,
            x: 1,
            y: 2,
            z: 3,
        }[a];
    }

    static decode(a) {
        return ['xyz', 'x', 'y', 'z'][a];
    }
}


 

class Geometry{
    static glyphVertCone(sampling = 10){
        let vert = [];
        let add = 2 * Math.PI / sampling;
        let size = 0.5;

        for (let i = 0; i < 2 * Math.PI; i += add){
            vert.push(0, size * Math.cos(i), size * Math.sin(i));
            vert.push(0, size * Math.cos(i + add), size * Math.sin(i + add));
            vert.push(size * 2, 0, 0);
        }

        for (let i = 0; i < 2 * Math.PI; i += add){
            vert.push(0, size * Math.cos(i), size * Math.sin(i));
            vert.push(0, size * Math.cos(i + add), size * Math.sin(i + add));
            vert.push(0, 0, 0);
        }

        return vert;
    }

    static glyphNormCone(sampling = 10){
        let vert = [];
        let add = 2 * Math.PI / sampling;
        let a, b;
        let x = vec3.create();
        let y = vec3.create();
        let c = vec3.create();
        let t = vec3.fromValues(2, 0, 0);

        for (let i = 0; i < 2 * Math.PI; i += add){
            a = vec3.fromValues(0, Math.cos(i), Math.sin(i));
            b = vec3.fromValues(0, Math.cos(i + add), Math.sin(i + add));
            vec3.sub(x, a, t);
            vec3.sub(y, b, t);
            vec3.cross(c, x, y);

            for (let k = 0; k < 3; k++){
                vert.push(c[0], c[1], c[2]);
            }
        }

        for (let i = 0; i < 2 * Math.PI; i += add){
            for (let k = 0; k < 3; k++){
                vert.push(-1, 0, 0);
            }
        }

        return vert;
    }

    static glyphVertLine(sampling, height = 4){
        let vert = [];
        let add = 2 * Math.PI / sampling;
        let size = 0.5;

        for (let i = 0; i < 2 * Math.PI; i += add){
            vert.push(0, size * Math.cos(i), size * Math.sin(i));
            vert.push(0, size * Math.cos(i + add), size * Math.sin(i + add));
            vert.push(size * height, size * Math.cos(i), size * Math.sin(i));

            vert.push(0, size * Math.cos(i + add), size * Math.sin(i + add));
            vert.push(size * height, size * Math.cos(i + add), size * Math.sin(i + add));
            vert.push(size * height, size * Math.cos(i), size * Math.sin(i));
        }

        for (let i = 0; i < 2 * Math.PI; i += add){
            vert.push(0, size * Math.cos(i + add), size * Math.sin(i + add));
            vert.push(0, size * Math.cos(i), size * Math.sin(i));
            vert.push(0, 0, 0);
        }

        for (let i = 0; i < 2 * Math.PI; i += add){
            vert.push(size * height, size * Math.cos(i), size * Math.sin(i));
            vert.push(size * height, size * Math.cos(i + add), size * Math.sin(i + add));
            vert.push(size * height, 0, 0);
        }

        return vert;
    }

    static glyphNormLine(sampling, height = 4){
        let vert = [];
        let add = 2 * Math.PI / sampling;
        let a, b;
        let x = vec3.create();
        let y = vec3.create();
        let c = vec3.create();
        let t = vec3.create();

        for (let i = 0; i < 2 * Math.PI; i += add){
            a = vec3.fromValues(0, Math.cos(i), Math.sin(i));
            b = vec3.fromValues(0, Math.cos(i + add), Math.sin(i + add));
            t = vec3.fromValues(height, Math.cos(i), Math.sin(i));
            vec3.sub(x, a, t);
            vec3.sub(y, b, t);
            vec3.cross(c, x, y);

            for (let k = 0; k < 6; k++){
                vert.push(c[0], c[1], c[2]);
            }
        }

        for (let i = 0; i < 2 * Math.PI; i += add){
            for (let k = 0; k < 3; k++){
                vert.push(-1, 0, 0);
            }
        }

        for (let i = 0; i < 2 * Math.PI; i += add){
            for (let k = 0; k < 3; k++){
                vert.push(1, 0, 0);
            }
        }

        return vert;
    }


    static streamVert(sampling, divisions = 10){
        let vert = [];

        for (let i = 0; i < divisions; ++i){
            vert = vert.concat(Geometry.glyphVertLine(sampling, 0));
        }

        return vert;
    } 


    static streamNorm(sampling, divisions = 10){
        let vert = [];

        for (let i = 0; i < divisions; ++i){
            vert = vert.concat(Geometry.glyphNormLine(sampling, 1));
        }

        return vert;
    }


    static streamLocalT(sampling, divisions = 10){
        let vert = [];
        let add = 2 * Math.PI / sampling;

        for (let i = 0; i < divisions; ++i){
            let base = i / divisions;
            let top = (i + 1) / divisions;

            for (let i = 0; i < 2 * Math.PI; i += add){
                vert.push(base, base, top, base, top, top);
            }

            for (let i = 0; i < 2 * Math.PI; i += add){
                vert.push(base, base, base);
            }

            for (let i = 0; i < 2 * Math.PI; i += add){
                vert.push(top, top, top);
            }

        }

        return vert;
    }

    static layerElements(sampling, normal){
        sampling.splice(normal,1);

        let elements = [];
        for (let b = 0; b < sampling[1] - 1; ++b){
            for (let a = 0; a < sampling[0] - 1; ++a){
                elements.push(a + 1 + b * sampling[1], a + b * sampling[1], a + sampling[0] + b * sampling[1]);
                elements.push(a + 1 + b * sampling[1], a + sampling[0] + b * sampling[1], a + 1 + sampling[0] + b * sampling[1]);
            }
        }

        return elements;

    }

    static get unitQuad(){
        return [
            -0.5, -0.5, 0,
            0.5, -0.5, 0,
            0.5, 0.5, 0,
            -0.5, -0.5, 0,
            0.5, 0.5, 0,
            -0.5, 0.5, 0,
        ];
    }

    static get unitQuadTex(){
        return [
            0, 1,
            1, 1,
            1, 0,
            0, 1,
            1, 0,
            0, 0,
        ];
    }
} 

class DType {
	static get int(){
		return 0;
	}

	static get float(){
		return 1;
	}
}

class Primitive {
    constructor(gl) {
		this.gl = gl;
		this.lateLoaded = false;
		this._data = null;
		
		//store buffers for auto delete and auto binding
		this.buffers = {
			vao : undefined,
			ebo : undefined,
			vbo: [],
		};

		//store textures for auto delete and autobinding
		this.textures = [];

		//draw sizes...
		this.sizes = {
			instances: 1,
			instanceSize: 1,
		};
	}

    get transparent() {
		if (!('meta' in this))
			return false;
        return this.meta.appearance === Appearance.transparent;
    }

    static base64totype(data, mode=DType.float) {
		let blob = window.atob(data);
		let array;

		if (mode === DType.float){
			let len = blob.length / Float32Array.BYTES_PER_ELEMENT;
			let view = new DataView(new ArrayBuffer(Float32Array.BYTES_PER_ELEMENT));
			array = new Float32Array(len);
	
			for (let p = 0; p < len * 4; p = p + 4) {
				view.setUint8(0, blob.charCodeAt(p));
				view.setUint8(1, blob.charCodeAt(p + 1));
				view.setUint8(2, blob.charCodeAt(p + 2));
				view.setUint8(3, blob.charCodeAt(p + 3));
				array[p / 4] = view.getFloat32(0, true);
			}
			view = null;

		} else if (mode === DType.int) {
			let len = blob.length / Int32Array.BYTES_PER_ELEMENT;
			let view = new DataView(new ArrayBuffer(Int32Array.BYTES_PER_ELEMENT));
			array = new Int32Array(len);
	
			for (let p = 0; p < len * 4; p = p + 4) {
				view.setUint8(0, blob.charCodeAt(p));
				view.setUint8(1, blob.charCodeAt(p + 1));
				view.setUint8(2, blob.charCodeAt(p + 2));
				view.setUint8(3, blob.charCodeAt(p + 3));
				array[p / 4] = view.getInt32(0, true);
			}
			view = null;
		}

		blob = null;
		return array;
	}

	//INIT MANAGEMENT
	get isRenderReady(){
		if (!this.loaded){
			this.init();
		}
		
		return this.loaded;
	}

	isInitReady(data){
		if (!this.program.loaded && data !== null){
			this._data = data;
			this.lateLoaded = true;
            return false;
        }

        if (this.program.loaded && (this._data !== null || data !== null)){
			return true;
		}
		
		return false;
	}

	lateLoadData(data){
		if (data === null && this.lateLoaded){
			data = this._data;
			this._data = null;
			return data;
		} else if (data !== null){
			return data;
		}
	}

	//BUFFERS MANAGEMENT
	initBoundingBox(data){
		this.box.init(data);
	}

	addBufferVAO(buffer){
		this.buffers.vao = buffer;
	}

	addBufferVBO(buffer){
		this.buffers.vbo.push(buffer);
	}

	addBufferEBO(buffer){
		this.buffers.ebo = buffer;
	}

	addTexture(texture) {
		this.textures.push(texture);
	}

	bindBuffersAndTextures(){
		this.gl.bindVertexArray(this.buffers.vao);

		for (let buffer of this.buffers.vbo){
			this.gl.bindBuffer(this.gl.ARRAY_BUFFER, buffer);
		}
		
		if (this.buffers.ebo !== undefined) {
			this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, this.buffers.ebo);
		}

		for (let texture of this.textures){
			this.gl.bindTexture(this.gl.TEXTURE_2D, texture);
		}
	}

	//META INFO MANAGEMENT
	metaFromData(meta, stats){
		this.meta = {};
	}

	appendMeta(options){
		this.meta = Object.assign({}, this.meta, options);
	}

	uniformDict(camera, light){
		return Object.assign({}, this.meta, {
			model: this.model,
			view: camera.view,
			proj: camera.projection,
			light: light.pos,
		});
	}

	//RESOURCES DELETE
    delete(){
		for (let texture of this.textures){
			this.gl.deleteTexture(this.gl.TEXTURE_2D, texture);
		}

		for (let buffer of this.buffers.vbo){
			this.gl.deleteBuffer(buffer);
		}
		
		if (this.buffers.ebo !== undefined) {
			this.gl.deleteBuffer(this.buffers.ebo);
		}

        this.gl.deleteVertexArray(this.buffers.vao);
    }
} 

class MethodPrimitive extends Primitive {
    //META INFO MANAGEMENT
	metaFromData(meta, stats){
        super.metaFromData(meta, stats);
        this.meta = Object.assign({}, this.meta, {
            colorMapSize: meta.colormap.sampling,
            colorMap0: vec4.fromValues(...meta.colormap.colors[0]),
            colorMap1: vec4.fromValues(...meta.colormap.colors[1]),
            colorMap2: vec4.fromValues(...meta.colormap.colors[2]),
            colorMap3: vec4.fromValues(...meta.colormap.colors[3]),
            colorMap4: vec4.fromValues(...meta.colormap.colors[4]),

            appearance: Appearance.encode(meta.appearance),
            brightness: 1.0,
            
            visible: true,
            boxVisible: true,
            lablesVisible: true,

            //save only values
            stats: stats.values,

            scaleFactor: stats.points.scale_factor,
            shift: stats.points.center,
        });
    }
    
    uniformDict(camera, light, statsMode = CoordMode.xyz){
        let unifs = super.uniformDict(camera, light);
		return Object.assign({}, unifs, this.meta.stats[CoordMode.decode(statsMode)]);
    }
    
    renderBox(camera, light){
        if (!this.meta.visible || !this.meta.boxVisible)
            return;


        this.box.render(camera, light);
    }

    renderLabels(camera, light){
        if (!this.meta.visible || !this.meta.boxVisible || !this.meta.lablesVisible)
            return;

        this.box.renderLabels(camera, light);
    }

    updateEdgeAxis(camera){
        this.box.updateEdgeAxis(camera);
    }

    get ui(){
        return {
            mode: {
                type: 'select',
                options: ['xyz', 'x', 'y', 'z'],
                callbacks: [
                    () => {this.meta.mode = CoordMode.xyz}, 
                    () => {this.meta.mode = CoordMode.x},
                    () => {this.meta.mode = CoordMode.y},
                    () => {this.meta.mode = CoordMode.z},
                ],
                value: 'xyz',
            },
            brightness: {
                type: 'slider',
                min: 0,
                max: 2,
                delta:  0.01,
                value: 1,
                callback: (value) => { this.meta.brightness = value },
            },
            visibility: {
                type: 'select',
                options: ['show', 'hide'],
                callbacks: [
                    () => {this.meta.visible = true}, 
                    () => {this.meta.visible = false},
                ],
                value: 'show',
            },
            box: {
                type: 'select',
                options: ['show', 'hide'],
                callbacks: [
                    () => {this.meta.boxVisible = true}, 
                    () => {this.meta.boxVisible = false},
                ],
                value: 'show',
            },
            lables: {
                type: 'select',
                options: ['show', 'hide'],
                callbacks: [
                    () => {this.meta.lablesVisible = true}, 
                    () => {this.meta.lablesVisible = false},
                ],
                value: 'show',
            }
        }
    }
} 

class UnitBox extends Primitive {
    constructor(gl, programs) {
        super(gl);
        this.program = programs.box;
        this.loaded = false;
    }

    init() {
        var boxVert = [
            1, 1, 1,
            1, 1, 0,
            0, 1, 0,
            0, 1, 1,
            1, 0, 1,
            1, 0, 0,
            0, 0, 0,
            0, 0, 1
        ];

        var boxInd = [
            0, 1,
            0, 3,
            2, 1,
            2, 3,
            4, 5,
            4, 7,
            6, 7,
            5, 6,
            0, 4,
            1, 5,
            3, 7,
            2, 6,
        ];

        /*var fullBoxInd = [
            6, 5, 4,
            6, 4, 7,
            5, 1, 0,
            5, 0, 4,
            1, 2, 3,
            1, 3, 0,
            2, 6, 7,
            2, 7, 3,
            7, 4, 0,
            7, 0, 3,
            2, 1, 5,
            2, 5, 6,
        ];*/

        // init VBO
        let vbo = this.gl.createBuffer();
        this.gl.bindBuffer(this.gl.ARRAY_BUFFER, vbo);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(boxVert), this.gl.STATIC_DRAW);
        this.addBufferVBO(vbo);

        // init EBO
        let ebo = this.gl.createBuffer();
        this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, ebo);
        this.gl.bufferData(this.gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(boxInd), this.gl.STATIC_DRAW);
        this.addBufferEBO(ebo);

        //init VAO
        let vao = this.gl.createVertexArray();
        this.gl.bindVertexArray(vao);
        this.addBufferVAO(vao);
        this.program.bindAttrPosition();
        this.gl.bindVertexArray(null);
            
        this.sizes.instanceSize = boxInd.length;
    }

    render(camera, light) {
        this.program.bind();
        this.bindBuffersAndTextures();

        let uniforms = this.uniformDict(camera, light);
        this.program.bindUniforms(uniforms);

        this.gl.drawElements(this.gl.LINES, this.sizes.instanceSize, this.gl.UNSIGNED_SHORT, 0);
        //console.log(this.gl.getError());

        this.gl.bindVertexArray(null);
        this.program.unbind();
    }
} 

class Stream extends MethodPrimitive {
    constructor(gl, programs) {
        super(gl);

        this.program = programs.stream;
        this.box = new Box(this.gl, programs);

        this.loaded = false;
        this.model = mat4.create();
    }

    init(data = null){
        //Belated initialization...
        if (!this.isInitReady(data))
            return;

        data = this.lateLoadData(data);

        //Actual initialization
        //load base64 data
        let positions = Primitive.base64totype(data.points);
        let values = Primitive.base64totype(data.values);
        let times = Primitive.base64totype(data.times);
        let lengths = Primitive.base64totype(data.lengths, DType.int);
        let segmentsCount = times.length - lengths.length;
        let streamsCount = lengths.length;
        let filled = 0;
        const segsize = 28;

        //console.log(positions, values, times, lengths);

        let vao = this.gl.createVertexArray();
        this.gl.bindVertexArray(vao);
        this.addBufferVAO(vao);
            
        //glyph positions
		let streambuffer = this.gl.createBuffer();
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, streambuffer);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, 
            segmentsCount * segsize * Float32Array.BYTES_PER_ELEMENT, 
            this.gl.STATIC_DRAW);
        this.addBufferVBO(streambuffer);


        //offset in positions and values array
        let poffset = 0;
        let voffset = 0;
        //offset in time array
        let toffset = 0;

        let copyVector = function(invec, outvec, inoffset, outoffset, veclen){
            for(let i = 0; i < veclen; ++i){
                outvec[outoffset + i] = invec[inoffset + i];
            }
        }

        //setup each streamline
        for (let i = 0; i < streamsCount; ++i){
            //lengths[i] - 1 == segment count
            let buffer = new Float32Array((lengths[i] - 1) * segsize);
            let streamLength = lengths[i];
            let streamSegments = streamLength - 1;
            //offset in buffer
            let boffset = 0;

            let zeroPosition = [];
            let zeroValue = [];
            let finalPosition = [];
            let finalValue = [];

            //for multiusage
            let tmpoffset;

            //extrapolate positions and values of the first
            for (let o = 0; o < 3; ++o){
                //offset of the first vertex
                tmpoffset = poffset + o;
                zeroPosition.push(positions[tmpoffset] + (positions[tmpoffset] - positions[tmpoffset + 3]));
                zeroValue.push(values[tmpoffset] + (values[tmpoffset] - values[tmpoffset + 3]));
            }

            //extrapolate positions and values of the last
            for (let o = 0; o < 3; ++o){
                //offset of the last vertex
                tmpoffset = poffset + o + (streamLength - 1) * 3;
                //minus 3 to get last-but-one
                finalPosition.push(positions[tmpoffset] + (positions[tmpoffset] - positions[tmpoffset - 3]));
                finalValue.push(values[tmpoffset] + (values[tmpoffset] - values[tmpoffset - 3]));
            }

            let zeroTime = times[toffset] + (times[toffset] - times[toffset + 1]);
            let finalTime = times[toffset + streamLength - 1] + (times[toffset + streamLength - 1] - times[toffset + streamLength - 2]);

            //console.log(poffset, voffset);
            /*setup each segment with structure:
             *
             * ...|p0 xyz|p1 xyz|p2 xyz|p3 xyz|v0 xyz|v1 xyz|v2 xyz|v3 xyz|t0123|...
             *     0      3      6      9      12     15     18     21     24
             * 
             * positions and values with stride 25
             * time with stride 24 
             */
            for (let s = 0; s < streamSegments; ++s){

                //each slice of position and value
                //copy them at once
                for (let p = 0; p < 4; ++p){
                    if (s == 0 && p == 0) {
                        //copy first
                        copyVector(zeroPosition, buffer, 0, boffset, 3);
                        copyVector(zeroValue, buffer, 0, boffset + 12, 3);
                        buffer[boffset + 24] = zeroTime;
                    } else if (s == (streamSegments - 1) && p == 3) {
                        //copy last
                        copyVector(finalPosition, buffer, 0, boffset + 9, 3);
                        copyVector(finalValue, buffer, 0, boffset + 21, 3);
                        buffer[boffset + 27] = finalTime;
                    } else {
                        //copy any other
                        copyVector(positions, buffer, poffset, boffset + 3 * p, 3);
                        copyVector(values, buffer, voffset, boffset + 12 + 3 * p, 3);
                        buffer[boffset + 24 + p] = times[toffset];
                        //console.log(s, positions[poffset], positions[poffset + 1], positions[poffset + 2]);

                        //move head over what was read
                        voffset += 3;
                        poffset += 3;
                        toffset += 1;
                    }
                }
                //move 3 slides back (one window is 4 slides)
                boffset += 28;
                voffset -= 9;
                poffset -= 9;
                toffset -= 3;
            }
            //move 3 slides forward
            poffset += 9;
            voffset += 9;
            toffset += 3;

            //append to buffer 
            this.gl.bufferSubData(this.gl.ARRAY_BUFFER, filled, buffer);
            filled += buffer.length * Float32Array.BYTES_PER_ELEMENT;
            buffer = null;
        }

        this.program.bindAttrBigBuffer();
        this.sizes.instances = segmentsCount;

        this.initSegment(data.meta.sampling, data.meta.divisions);
        this.gl.bindVertexArray(null);
        
        //meta and stats
        this.metaFromData(data.meta, data.stats);
        this.appendMeta({
            size: data.meta.size,
            time: [data.meta.t0, data.meta.tbound],
            t0: data.meta.t0,
            tbound: data.meta.tbound,
            culling: true,
            mode: CoordMode.xyz,
        });

        //init bounding box
        this.initBoundingBox(data);

        //Finish up...
        this.loaded = true;  
        //console.log(this.gl.getError());
        //console.log(this.program);
        //console.log(this.meta);

        //console.log(this.buffers);
    }

    initSegment(sampling, divisions){
        let vert = Geometry.streamVert(sampling, divisions); 
        let norm = Geometry.streamNorm(sampling, divisions);
        let t = Geometry.streamLocalT(sampling, divisions);

        // init VBO for stream positions
		let positions = this.gl.createBuffer();
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, positions);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(vert), this.gl.STATIC_DRAW);
        this.addBufferVBO(positions);
        this.program.bindAttrPosition();

        // init VBO for stream normals
		let normals = this.gl.createBuffer();
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, normals);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(norm), this.gl.STATIC_DRAW); 
        this.addBufferVBO(normals);
        this.program.bindAttrNormal();

        // init VBO for stream local time
		let times = this.gl.createBuffer();
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, times);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(t), this.gl.STATIC_DRAW); 
        this.addBufferVBO(times);
        this.program.bindAttrTime();

        this.sizes.instanceSize = vert.length / 3;
    }

    render(camera, light){
        if(!this.isRenderReady)
            return;

        if(!this.meta.visible)
            return;

        let culling = this.meta.culling;

        if (culling){
            this.gl.enable(this.gl.CULL_FACE);
            this.gl.cullFace(this.gl.BACK);
        }

        this.program.bind();
        this.bindBuffersAndTextures();

        let uniforms = this.uniformDict(camera, light, this.meta.mode);
        //console.log(uniforms);
        this.program.bindUniforms(uniforms);

        //console.log(this.sizes.instanceSize, this.sizes.instances);
        this.gl.drawArraysInstanced(this.gl.TRIANGLES, 0, this.sizes.instanceSize, this.sizes.instances);
        //console.log(this.gl.getError());

        this.gl.bindVertexArray(null);
        this.program.unbind();

        if (culling){
            this.gl.disable(this.gl.CULL_FACE);
        }
    }

    get ui(){
        let t0 = 'meta' in this ? this.meta.t0: this._data.meta.t0;
        let tbound = 'meta' in this ? this.meta.tbound: this._data.meta.tbound;

        return Object.assign({}, {
            type: {
                type: 'display',
                value: 'streamlines',
            },
            appearance: {
                type: 'select',
                options: ['solid', 'transparent'],
                callbacks: [
                    () => {this.meta.appearance = Appearance.solid}, 
                    () => {this.meta.appearance = Appearance.transparent},
                ],
                value: 'meta' in this ? Appearance.decode(this.meta.appearance): this._data.meta.appearance,
            },
            culling: {
                type: 'select',
                options: ['on', 'off'],
                callbacks: [
                    () => {this.meta.culling = true}, 
                    () => {this.meta.culling = false},
                ],
                value: 'on',
            },
            size: {
                type: 'slider',
                min: 0.01,
                max: 10,
                delta: 0.01,
                value: 'meta' in this ? this.meta.size: this._data.meta.size,
                callback: (value) => { this.meta.size = value },
            },
            t_start: {
                type: 'slider',
                min: t0,
                max: tbound,
                delta:  (tbound - t0) / 1000,
                value: t0,
                callback: (value) => { this.meta.time[0] = value },
            },
            t_end: {
                type: 'slider',
                min: t0,
                max: tbound,
                delta:  (tbound - t0) / 1000,
                value: tbound,
                callback: (value) => { this.meta.time[1] = value },
            },
        }, super.ui);
    }
} 

class Box extends UnitBox {
    constructor(gl, programs) {
        super(gl, programs);
        this.labels = [];
        this.loaded = false;

        this.programs = programs;
        this.activeEdge = {
            0: 0,
            1: 0,
            2: 0,
        };
    }

    init(data = null) {
        //Belated initialization...
        if (!this.isInitReady(data))
            return;

        data = this.lateLoadData(data);
        super.init(data);

        let start = Primitive.base64totype(data.meta.bounds.start);
        vec3.sub(start, start, data.stats.points.center);
        vec3.scale(start, start, data.stats.points.scale_factor);

        let dim = Primitive.base64totype(data.meta.bounds.dim);
        vec3.scale(dim, dim, data.stats.points.scale_factor);

        //meta to be used later
        this.meta = {
            start: start,
            dim: dim,
            labelStart: Primitive.base64totype(data.meta.bounds.start),
            labelDim: Primitive.base64totype(data.meta.bounds.dim),
        }

        //model matrix
        let matrix = mat4.create();
        matrix = mat4.translate(mat4.create(), matrix, start);
        matrix = mat4.scale(mat4.create(), matrix, dim);
        this.model = matrix;

        // active edges
        let x = [ vec3.create(), vec3.create(), vec3.create(), vec3.create() ];
        let y = [ vec3.create(), vec3.create(), vec3.create(), vec3.create() ];
        let z = [ vec3.create(), vec3.create(), vec3.create(), vec3.create() ];

        //half of the dimensions
        let halves = vec3.scale(vec3.create(), dim, 0.5);

        for (let i in x){
            x[i][0] = halves[0];
            x[i][1] = i % 2             ? start[1] : start[1] + dim[1]; 
            x[i][2] = Math.floor(i / 2) ? start[2] : start[2] + dim[2]; 
        }

        for (let i in y){
            y[i][0] = i % 2             ? start[0] : start[0] + dim[0]; 
            y[i][1] = halves[1];
            y[i][2] = Math.floor(i / 2) ? start[2] : start[2] + dim[2]; 
        }

        for (let i in z){
            z[i][0] = i % 2             ? start[0] : start[0] + dim[0]; 
            z[i][1] = Math.floor(i / 2) ? start[1] : start[1] + dim[1]; 
            z[i][2] = halves[2];
        }

        this.edgeCenters = {
            0: x,
            1: y,
            2: z,
        };

        //center
        this.meta['center'] = vec3.add(vec3.create(), start, halves);

        //add labels
        let sampling = [];
        
        for (let i = 0; i < 3; ++i){
            sampling.push(Math.max(3, Math.min(30, Math.floor(dim[i] / 40) * 5)));
        }

        this.addLabels(sampling);
        this.loaded = true;
    }


    addLabels(sampling){
        let max, addPosition, addLabelValue;

        for (let axisIndex in sampling){
            max = this.meta.start[axisIndex] + this.meta.dim[axisIndex];
            
            //space
            addPosition = this.meta.dim[axisIndex] / sampling[axisIndex];
            //text
            addLabelValue = this.meta.labelDim[axisIndex] / sampling[axisIndex];
            
            let pos = this.meta.start[axisIndex];
            let labelValue = this.meta.labelStart[axisIndex];

            if (addPosition == 0){
                //in case it has 0 width
                this.addLabel(axisIndex, pos, labelValue);
            } else {
                //non zero width
                while (pos <= max){
                    this.addLabel(axisIndex, pos, labelValue);
                    pos += addPosition;
                    labelValue += addLabelValue;
                }
            }


        }

    }

    addLabel(axis, value, labelValue){
        let start = this.meta.start;
        let dim = this.meta.dim;
        let shift = vec3.create();

        for (let i  = 0; i < 4; ++i){
            let position = vec3.create();

            if (axis == 0){
                position[0] = value;
                position[1] = i % 2             ? start[1] : start[1] + dim[1]; 
                position[2] = Math.floor(i / 2) ? start[2] : start[2] + dim[2]; 
            } else if (axis == 1){
                position[0] = i % 2             ? start[0] : start[0] + dim[0]; 
                position[1] = value;
                position[2] = Math.floor(i / 2) ? start[2] : start[2] + dim[2]; 
            } else if (axis == 2){
                position[0] = i % 2             ? start[0] : start[0] + dim[0]; 
                position[1] = Math.floor(i / 2) ? start[1] : start[1] + dim[1]; 
                position[2] = value;
            }

            vec3.subtract(shift, position, this.meta.center);
            shift[axis] = 0;
            vec3.scaleAndAdd(position, position, shift, 1 / vec3.len(shift)); 

            let quad = new Quad(this.gl, this.programs);
            quad.init({
                position: position,
                value: labelValue,
            });

            quad.boxMeta = {
                axis: axis,
                edge: i,
            };

            this.labels.push(quad);

        }
    }

    updateEdgeAxis(camera){
        let camPosition = camera.position;
        let distClosest, distSecond;
        let closest, second;
        let tmpDist;

        for (let ax in this.edgeCenters){
            distClosest = Infinity;
            distSecond = Infinity;
            for (let edge in this.edgeCenters[ax]){
                //calc distance between you and center of the edge
                tmpDist = vec3.dist(this.edgeCenters[ax][edge], camPosition);
                //when the edge is the closest yet
                if (tmpDist < distClosest) {
                    second = closest;
                    distSecond = distClosest;
                    closest = edge;
                    distClosest = tmpDist;

                //when the edge is the second closest
                } else if (tmpDist < distSecond){
                    second = edge;
                    distSecond = tmpDist;
                }
            }

            this.activeEdge[ax] = parseInt(second);
        }
    }

    render(camera, light) {
        if(!this.isRenderReady)
            return;

        super.render(camera, light);
    }

    renderLabels(camera, light){
        for (let lable of this.labels){

            if (this.activeEdge[lable.boxMeta.axis] !== lable.boxMeta.edge)
                continue;

                lable.render(camera, light);
            //console.log('rendering', 'axis', lable.boxMeta.axis, 'edge', this.activeEdge[lable.boxMeta.axis]);
        }
    }

    delete() {
        super.delete();
        for (let label of this.labels){
            label.delete();
        }
    }
} 

class Glyphs extends MethodPrimitive {
    constructor(gl, programs) {
        super(gl);
        
        this.program = programs.glyph;
        this.box = new Box(gl, programs);
        this.loaded = false;

        this.model = mat4.create();
    }

    init(data = null){
        //Belated initialization...
        if (!this.isInitReady(data))
            return;
        data = this.lateLoadData(data);

        //Actual initialization
        //load base64 data
        let positions = Primitive.base64totype(data.points);
        let values = Primitive.base64totype(data.values);

        //init VAO
        let vao = this.gl.createVertexArray();
        this.gl.bindVertexArray(vao);
        this.addBufferVAO(vao);
    
        //glyph positions
		let positionsVbo = this.gl.createBuffer();
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, positionsVbo);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, positions, this.gl.STATIC_DRAW);
        this.addBufferVBO(positionsVbo);
        this.program.bindAttrFieldPosition();
 
        //glyph values
        let valuesVbo = this.gl.createBuffer();
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, valuesVbo);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, values, this.gl.STATIC_DRAW);  
        this.addBufferVBO(valuesVbo);  
        this.program.bindAttrFieldValue();

        //sizes setup
        this.sizes.instances = positions.length / 3;
        
        //init glyph
        this.initGlyph(data.meta.geometry, data.meta.sampling);
        this.gl.bindVertexArray(null);

        //setup class meta info
        this.metaFromData(data.meta, data.stats);
        this.appendMeta({
            size: data.meta.size,
            mode: CoordMode.encode('xyz'),
        });

        //init bounding box
        this.initBoundingBox(data);

        //Finish up...
        this.loaded = true;  
        //console.log(this.gl.getError());
        console.log(this.program);
    }

    initGlyph(geometry, sampling){
        let lineVert, lineNorm;

        if (geometry === 'line'){
            lineVert = Geometry.glyphVertLine(sampling);
            lineNorm = Geometry.glyphNormLine(sampling);
        } else if (geometry === 'cone'){
            lineVert = Geometry.glyphVertCone(sampling);
            lineNorm = Geometry.glyphNormCone(sampling); 
        }

        // init VBO for glyph positions
		let positions = this.gl.createBuffer();
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, positions);
		this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(lineVert), this.gl.STATIC_DRAW);
        this.addBufferVBO(positions);
        this.program.bindAttrVertexPosition();

        // init VBO for glyph normals
		let normals = this.gl.createBuffer();
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, normals);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(lineNorm), this.gl.STATIC_DRAW); 
        this.addBufferVBO(normals);
        this.program.bindAttrVertexNormal();
        
        //sizes setup
        this.sizes.instanceSize = lineVert.length / 3;
        //console.log(this.program);
    }

    render(camera, light){
        if(!this.isRenderReady)
            return;

        if(!this.meta.visible)
            return;

        this.program.bind();
        this.bindBuffersAndTextures();
        
        //create uniforms
        let uniforms = this.uniformDict(camera, light, this.meta.mode);
        //console.log(uniforms);
        this.program.bindUniforms(uniforms);

        this.gl.drawArraysInstanced(this.gl.TRIANGLES, 0, this.sizes.instanceSize, this.sizes.instances);
        //console.log(this.gl.getError());

        this.gl.bindVertexArray(null);
        this.program.unbind();
    }

    get ui(){
        return Object.assign({}, {
            type: {
                type: 'display',
                value: 'glyphs',
            },
            appearance: {
                type: 'select',
                options: ['solid', 'transparent'],
                callbacks: [
                    () => {this.meta.appearance = Appearance.solid}, 
                    () => {this.meta.appearance = Appearance.transparent},
                ],
                value: 'meta' in this ? Appearance.decode(this.meta.appearance): this._data.meta.appearance,
            },
            size: {
                type: 'slider',
                min: 0.1,
                max: 10,
                delta: 0.01,
                value: 'meta' in this ? this.meta.size: this._data.meta.size,
                callback: (value) => { this.meta.size = value },
            },
        }, super.ui);
    }
} 

class Quad extends Primitive {
    constructor(gl, programs) {
        super(gl);
        this.program = programs.text;
        this.loaded = false;

        this.model = mat4.create();
        this.size = vec2.create();
    }

    init(data = null) {
        //Belated initialization...
        //console.log(this.loaded, this._data, this.program.loaded);
        //console.log('init quad');
        if (!this.isInitReady(data))
            return;
        data = this.lateLoadData(data);

        let geometry = Geometry.unitQuad;
        let uv = Geometry.unitQuadTex;

        let vao = this.gl.createVertexArray();
        this.gl.bindVertexArray(vao);
        this.addBufferVAO(vao);

        // init VBO for positions
		let positions = this.gl.createBuffer();
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, positions);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(geometry), this.gl.STATIC_DRAW);
        this.addBufferVBO(positions);
        this.program.bindAttrPosition();

        // init VBO for texcoord
		let texcoord = this.gl.createBuffer();
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, texcoord);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(uv), this.gl.STATIC_DRAW);
        this.addBufferVBO(texcoord);
        this.program.bindAttrTexcoord();

        
        //////////////////////////////////
        
        let textCtx = document.createElement("canvas").getContext("2d");
        
        // Puts text in center of canvas.
        function makeTextCanvas(text, width, height) {
            textCtx.canvas.width  = width;
            textCtx.canvas.height = height;
            textCtx.font = "20px monospace";
            textCtx.textAlign = "center";
            textCtx.textBaseline = "middle";
            textCtx.fillStyle = "white";
            textCtx.strokeStyle = 'white';
            textCtx.lineWidth = 5;
            textCtx.clearRect(0, 0, textCtx.canvas.width, textCtx.canvas.height);
            textCtx.fillText(text, width / 2, height / 2);
            return textCtx.canvas;
        }
        

        // create text texture.
        let value = data.value < 100 ? data.value.toFixed(2) : data.value.toExponential(3);
        let textCanvas = makeTextCanvas(value, 200, 50);
        let textWidth  = textCanvas.width;
        let textHeight = textCanvas.height;
        let textTex = this.gl.createTexture();
        this.gl.bindTexture(this.gl.TEXTURE_2D, textTex);
        this.gl.texImage2D(this.gl.TEXTURE_2D, 0, this.gl.RGBA, this.gl.RGBA, this.gl.UNSIGNED_BYTE, textCanvas);
        this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MIN_FILTER, this.gl.LINEAR);
        this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_WRAP_S, this.gl.CLAMP_TO_EDGE);
        this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_WRAP_T, this.gl.CLAMP_TO_EDGE);
        this.addTexture(textTex);
       
        
        this.appendMeta({
            labelSize: vec2.fromValues(textWidth, textHeight),
            texture: textTex,
        });
        
        mat4.fromTranslation(this.model, data.position);

        this.loaded = true;
        this._data = null;
        this.gl.bindVertexArray(null);
        this.gl.bindTexture(this.gl.TEXTURE_2D, null);

        console.log(this.gl.getError());
    }

    render(camera, light) {
        if(!this.isRenderReady)
            return;

        this.program.bind();
        this.bindBuffersAndTextures();

        let uniforms = this.uniformDict(camera, light);
        uniforms['screenSize'] = camera.screenDim;
        //console.log(uniforms);
        this.program.bindUniforms(uniforms);

        this.gl.drawArrays(this.gl.TRIANGLES, 0, 6);
        //console.log(this.gl.getError());

        this.gl.bindVertexArray(null);
        this.gl.bindTexture(this.gl.TEXTURE_2D, null);
        this.program.unbind();
    }
} 

class Layer extends MethodPrimitive {
    constructor(gl, programs) {
        super(gl);
        this.program = programs.layer;
        this.box = new Box(this.gl, programs);

        this.loaded = false;
        this.model = mat4.create();
    }

    init(data = null){
        //Belated initialization...
        if (!this.isInitReady(data))
            return;
        data = this.lateLoadData(data);

        //Actual initialization
        //load base64 data
        let positions = Primitive.base64totype(data.points);
        let values = Primitive.base64totype(data.values);
        let elements = Geometry.layerElements(data.meta.geometry.sampling, data.meta.geometry.normal);

        //setup vao
        let vao = this.gl.createVertexArray();
        this.gl.bindVertexArray(vao);
        this.addBufferVAO(vao);
            
        //positions
		let positionsVbo = this.gl.createBuffer();
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, positionsVbo);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, positions, this.gl.STATIC_DRAW);
        this.addBufferVBO(positionsVbo);
        this.program.bindAttrPosition();
        
        //values
        let valuesVbo = this.gl.createBuffer();
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, valuesVbo);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, values, this.gl.STATIC_DRAW);    
        this.addBufferVBO(valuesVbo);
        this.program.bindAttrValue();

        //elements
        let ebo = this.gl.createBuffer();
        this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, ebo);
        this.gl.bufferData(this.gl.ELEMENT_ARRAY_BUFFER, new Uint32Array(elements), this.gl.STATIC_DRAW);
        this.addBufferEBO(ebo);

        this.sizes.instanceSize = elements.length;
        this.gl.bindVertexArray(null);

        //Calculate stats
        this.metaFromData(data.meta, data.stats);
        this.appendMeta({
            normal: [[1, 0, 0], [0, 1, 0], [0, 0, 1]][data.meta.geometry.normal],
            mode: CoordMode.encode('xyz'),
        });

        //init bounding box
        this.initBoundingBox(data);

        //Finish up...
        this.loaded = true;  
        //console.log(this.gl.getError());
    }

    render(camera, light){
        if(!this.isRenderReady)
            return;

        if(!this.meta.visible)
            return;

        this.program.bind();
        this.bindBuffersAndTextures();

        let uniforms = this.uniformDict(camera, light, this.meta.mode);
        uniforms['cameraPosition'] = camera.pos;
        this.program.bindUniforms(uniforms);
        

        this.gl.drawElements(this.gl.TRIANGLES, this.sizes.instanceSize, this.gl.UNSIGNED_INT, 0);
        //console.log(this.gl.getError());

        this.gl.bindVertexArray(null);
        this.program.unbind();
    }

    get ui(){
        return Object.assign({}, {
            type: {
                type: 'display',
                value: 'plane',
            },
            appearance: {
                type: 'select',
                options: ['solid', 'transparent'],
                callbacks: [
                    () => {this.meta.appearance = Appearance.solid}, 
                    () => {this.meta.appearance = Appearance.transparent},
                ],
                value: 'meta' in this ? Appearance.decode(this.meta.appearance): this._data.meta.appearance,
            },
        }, super.ui);
    }
} 

class Light{
    constructor(){
        this.pos = vec3.fromValues(-20, 20, -20);
    }

    get position(){
        return this.pos;
    }
} 

const MOVE_STEP = 0.5;
const ROT_STEP = 0.5;

const ZOOM_STEP = 0.001;

class CameraPosition {
    static get top() {
        return 1;
    }

    static get front() {
        return 2;
    }

    static get side() {
        return 3;
    }

    static get moveUp() {
        return 4;
    }

    static get moveDown() {
        return 5;
    }

    static get rotateUp() {
        return 6;
    }

    static get rotateDown() {
        return 7;
    }

    static get rotateRight() {
        return 8;
    }

    static get rotateLeft() {
        return 9;
    }

    static get origin() {
        return 10;
    }
}


class CameraState {
    static get perspective() {
        return 0;
    }

    static get ortho() {
        return 1;
    }
}


class Camera {
    constructor() {
        this.position = vec3.fromValues(0, -20, 0);
        this.up = vec3.fromValues(0, 0, 1);
        this.center = vec3.fromValues(0, 0, 0);
        this.normal = vec3.create();
        this.scale = 100;

        this.viewMatrix = new Float32Array(16);
        this.projectionMatrix = new Float32Array(16);
        this.rotateMatrix = new Float32Array(16);
        this.frontVector = new Float32Array(3);
        this.tmp = new Float32Array(3);
        this.tmp2 = new Float32Array(3);

        //constatnts
        this.globalSide = vec3.fromValues(50, 0, 0);
        this.globalFront = vec3.fromValues(0, -50, 0);
        this.globalUp = vec3.fromValues(0, 0, 50);
        this.aspect = 1;
        this.screenX = 1;
        this.screenY = 1;
        this.speed = 0.05;

        //state
        this.actualPosition = vec3.fromValues(0, -20, 0);
        this.actualUp = vec3.fromValues(0, 0, 1);
        this.actualCenter = vec3.fromValues(0, 0, 0);
        this.actualScale = 100;
        
        this.positionMomentum = 0;
        this.centerMomentum = 0;
        this.rotMomentum = 0;
        this.scaleMomentum = 0;

        this.mode = CameraState.perspective;
    }

    get view() {
        if (this.mode === CameraState.perspective){
            return mat4.lookAt(this.viewMatrix, this.actualPosition, this.actualCenter, this.actualUp);
        } else {
            vec3.sub(this.tmp, this.actualPosition, this.actualCenter);
            vec3.normalize(this.tmp, this.tmp);
            vec3.scale(this.tmp, this.tmp, 1000);
            vec3.add(this.tmp, this.actualCenter, this.tmp);
            return mat4.lookAt(this.viewMatrix, this.tmp, this.actualCenter, this.actualUp);
        }
    }

    get projection() {
        if (this.mode === CameraState.perspective){
            return mat4.perspective(this.projectionMatrix, glMatrix.toRadian(45), this.aspect, 0.1, 2000.0);
        } else {
            return mat4.ortho(this.projectionMatrix, -this.actualScale, this.actualScale, -this.actualScale / this.aspect, this.actualScale / this.aspect, 0.1, 2000.0);
        }

    }

    get front() {
        vec3.sub(this.frontVector, this.center, this.position);
        return vec3.normalize(this.frontVector, this.frontVector);
    }

    get screenDim() {
        return vec2.fromValues(this.screenX, this.screenY);
    }

    get pos() {
        return this.actualPosition; 
    }

    screen(x, y){
        this.screenX = x;
        this.screenY = y;
        this.aspect = x / y;
    }


    setPosition(position){
        if (position === CameraPosition.top){
            
            let length = vec3.dist(this.position, this.center);
            this.globalUp[2] = Math.max(1.0, length);
            vec3.add(this.position, this.center, this.globalUp);
            this.up = vec3.fromValues(0, 1, 0);

        } else if (position === CameraPosition.front){

            let length = vec3.dist(this.position, this.center);
            this.globalFront[1] = Math.min(-1.0, -length);
            vec3.add(this.position, this.center, this.globalFront);
            this.up = vec3.fromValues(0, 0, 1);

        } else if (position === CameraPosition.side){
            
            let length = vec3.dist(this.position, this.center);
            this.globalSide[0] = Math.max(1.0, length);
            vec3.add(this.position, this.center, this.globalSide);
            this.up = vec3.fromValues(0, 0, 1);

        } else if (position === CameraPosition.rotateUp || position === CameraPosition.rotateDown) {
            
            let angle = (position === CameraPosition.rotateUp) ? glMatrix.toRadian(1) : glMatrix.toRadian(-1);
            
            vec3.sub(this.tmp2, this.center, this.position);
            let axes_x = vec3.cross(this.tmp, this.up, this.front);
            
            mat4.fromRotation(this.rotateMatrix, angle, axes_x);
            vec3.transformMat4(this.tmp2, this.tmp2, this.rotateMatrix);
            vec3.add(this.position, this.center, vec3.negate(this.tmp2, this.tmp2))
            vec3.transformMat4(this.up, this.up, this.rotateMatrix);
        
        } else if (position === CameraPosition.rotateRight || position === CameraPosition.rotateLeft) {
            let angle = position === CameraPosition.rotateRight ? glMatrix.toRadian(1) : glMatrix.toRadian(-1);
            
            vec3.sub(this.tmp2, this.center, this.position);
            let axes_y = this.globalUp;
            
            mat4.fromRotation(this.rotateMatrix, angle, axes_y);
            vec3.transformMat4(this.tmp2, this.tmp2, this.rotateMatrix);
            vec3.add(this.position, this.center, vec3.negate(this.tmp2, this.tmp2))
            vec3.transformMat4(this.up, this.up, this.rotateMatrix);
        
        } else if (position === CameraPosition.moveUp){

            vec3.add(this.position, this.position, this.up);
            vec3.add(this.center, this.center, this.up);

        } else if (position === CameraPosition.moveDown){

            vec3.add(this.position, this.position, vec3.negate(this.tmp, this.up));
            vec3.add(this.center, this.center, vec3.negate(this.tmp, this.up));

        } else if (position === CameraPosition.origin){

            this.position = vec3.fromValues(0, -20, 0);
            this.up = vec3.fromValues(0, 0, 1);
            this.center = vec3.fromValues(0, 0, 0);

        }
    }


    moveFront(scale = 1) {
        if (this.mode === CameraState.perspective){
            vec3.sub(this.tmp, this.position, this.center);
            vec3.scale(this.tmp, this.tmp, 1 - (ZOOM_STEP * scale));
            vec3.add(this.tmp, this.center, this.tmp);
            vec3.copy(this.position, this.tmp);
        } else {
            this.scale = this.scale * (1 - (ZOOM_STEP * 0.5 * scale));
        }

    }


    moveBack(scale = 1) {
        if (this.mode === CameraState.perspective){
            vec3.sub(this.tmp, this.position, this.center);
            vec3.scale(this.tmp, this.tmp, 1 + (ZOOM_STEP * scale));
            vec3.add(this.tmp, this.center, this.tmp);
            vec3.copy(this.position, this.tmp);
        } else {
            this.scale = this.scale * (1 + (ZOOM_STEP * 0.5 * scale));
        }

    }


    moveLeft(scale = 1) {
        vec3.sub(this.tmp, this.center, this.position);
        vec3.cross(this.normal, this.up, this.tmp);
        vec3.normalize(this.normal, this.normal);

        vec3.scaleAndAdd(this.position, this.position, this.normal, MOVE_STEP * scale);
        vec3.scaleAndAdd(this.center, this.center, this.normal, MOVE_STEP * scale);
    }

    moveRight(scale = 1) {
        vec3.sub(this.tmp, this.center, this.position);
        vec3.cross(this.normal, this.up, this.tmp);
        vec3.normalize(this.normal, this.normal);
        vec3.negate(this.normal, this.normal);

        vec3.scaleAndAdd(this.position, this.position, this.normal, MOVE_STEP * scale);
        vec3.scaleAndAdd(this.center, this.center, this.normal, MOVE_STEP * scale);
    }


    rotate(x, y) {
        let a_x = glMatrix.toRadian(-x) * ROT_STEP;
        let a_y = glMatrix.toRadian(y) * ROT_STEP;
        let front = vec3.sub(vec3.create(), this.center, this.position);

        let axes_x = vec3.cross(this.tmp, this.up, this.front);
        let axes_y = this.up;

        mat4.fromRotation(this.rotateMatrix, a_x, axes_y);
        mat4.rotate(this.rotateMatrix, this.rotateMatrix, a_y, axes_x);
        vec3.transformMat4(front, front, this.rotateMatrix);
        
        vec3.add(this.position, this.center, vec3.negate(front, front))
        vec3.transformMat4(this.up, this.up, this.rotateMatrix);
    }

    frame(){
        vec3.sub(this.tmp, this.position, this.actualPosition);
        this.positionMomentum = Math.min(vec3.length(this.tmp), this.speed * 2.0);
        if (this.positionMomentum > 0.02){
            vec3.scaleAndAdd(this.actualPosition, this.actualPosition, this.tmp, this.positionMomentum);
        } else {
            vec3.copy(this.actualPosition, this.position);
            this.positionMomentum = 0;
        }
        
        this.rotMomentum = Math.min(vec3.angle(this.actualUp, this.up), this.speed * 3.14);
        if (this.rotMomentum > 0.02) {
            let axis = vec3.cross(this.tmp, this.actualUp, this.up);
            mat4.fromRotation(this.rotateMatrix, this.rotMomentum, axis);
            vec3.transformMat4(this.actualUp, this.actualUp, this.rotateMatrix);   
        } else {
            vec3.copy(this.actualUp, this.up);
            this.rotMomentum = 0;
        }

        vec3.sub(this.tmp, this.center, this.actualCenter);
        this.centerMomentum = Math.min(vec3.length(this.tmp), this.speed * 2.0);
        if (this.centerMomentum > 0.02){
            vec3.scaleAndAdd(this.actualCenter, this.actualCenter, this.tmp, this.centerMomentum);
        } else {
            vec3.copy(this.actualCenter, this.center);
            this.centerMomentum = 0;
        }

        this.scaleMomentum = (this.scale - this.actualScale) * this.speed;
        if (this.scaleMomentum > 0.02){
            this.actualScale = this.actualScale + (this.scale - this.actualScale) * this.scaleMomentum;
        } else {
            this.actualScale = this.scale;
            this.scaleMomentum = 0;
        }

    }

    get isMoving(){
        if (this.centerMomentum || this.rotMomentum || this.positionMomentum || this.scaleMomentum){
            //console.log(this.centerMomentum, this.rotMomentum, this.positionMomentum);
            return true;
        }
        return false;
    }


    toggleMode(){
        if (this.mode === CameraState.perspective){
            this.mode = CameraState.ortho;
        } else {
            this.mode = CameraState.perspective;
        }
    }
} 

class Scene{
    constructor(gl){
        this.gl = gl;
        this.camera = new Camera();
        this.light = new Light();
        this.objects = [];
    }

    init(contents, ui, programs){
        console.log('loading scene elements');
        let sceneui = new SceneUI();

        contents.stats.points.center = Primitive.base64totype(contents.stats.points.center);
        contents.stats.points.min = Primitive.base64totype(contents.stats.points.min);
        contents.stats.points.max = Primitive.base64totype(contents.stats.points.max);
        console.log(contents.stats);


       /* let box = new Box(this.gl);
        box.init(vec3.fromValues(-10, -10, 0), vec3.fromValues(20, 20, 40));
        this.objects.push(box); */
        
        if ('glyphs' in contents){
            for (let glyphs_group of contents.glyphs){
                let glyphs = new Glyphs(this.gl, programs);
                glyphs_group.stats = contents.stats;
                glyphs.init(glyphs_group);
                //console.log(glyphs);
                this.objects.push(glyphs);

                sceneui.addWidget(new WidgetUI(glyphs.ui));
            }
        }

        if ('streamlines' in contents){
            for (let stream_group of contents.streamlines){
                let streams = new Stream(this.gl, programs);
                stream_group.stats = contents.stats;
                streams.init(stream_group);
                //console.log(streams);
                this.objects.push(streams);

                sceneui.addWidget(new WidgetUI(streams.ui));
            }
        }

        if ('layer' in contents){
            for (let layer_group of contents.layer){
                let layer = new Layer(this.gl, programs);
                layer_group.stats = contents.stats;
                layer.init(layer_group);
                //console.log(streams);
                this.objects.push(layer);

                sceneui.addWidget(new WidgetUI(layer.ui));
            }
        }
        /*

        let stream = new Stream(this.gl);
        stream.segment([0, 0, 0], [1, 0, 0], [1, 1, 0], [1, 0, 0]);*/

        //append ui
        ui.addScene(sceneui);
    }

    render(){
        this.gl.clearColor(0.1, 0.1, 0.1, 1.0);
        this.gl.clear(this.gl.DEPTH_BUFFER_BIT | this.gl.COLOR_BUFFER_BIT);
            
        this.gl.enable(this.gl.DEPTH_TEST);
        this.gl.enable(this.gl.BLEND);
        this.gl.blendFunc(this.gl.SRC_ALPHA, this.gl.ONE);
        
        //draw bounding boxes   
        for(let obj of this.objects){
            obj.renderBox(this.camera, this.light);
        }
        
        //draw solid objects
        this.gl.disable(this.gl.BLEND);
        for(let obj of this.objects){
            if (!obj.transparent){
                obj.render(this.camera, this.light);
            }
        }
        
        //draw transparent objects
        this.gl.enable(this.gl.BLEND);
        this.gl.blendFunc(this.gl.SRC_ALPHA, this.gl.ONE);
        for(let obj of this.objects){
            if (obj.transparent){
                obj.render(this.camera, this.light);
            }
        }
        
        this.gl.blendFunc(this.gl.ONE, this.gl.ONE_MINUS_SRC_ALPHA);
        this.gl.disable(this.gl.DEPTH_TEST);
        
        //bounding boxes labels  
        for(let obj of this.objects){
            obj.renderLabels(this.camera, this.light);
        }

        //update camera
        this.camera.frame();

        //check for camera movement
        if (this.camera.isMoving){
            for(let obj of this.objects){
                obj.updateEdgeAxis(this.camera);
            }
            //console.log('camera is moving');
        }
    }

    screen(x, y) {
        this.camera.screen(x, y);
    }

    delete() {
        console.log('deleting scene...');
        for (let obj of this.objects){
            obj.delete();
        }
    }
} 

class Graphics {
    constructor(canvas) {
		this.canvas = canvas;
		this.scenes = [];

		//active scene
		this.scene = null;
    }

    init() {
		console.log('Getting webgl 2 context');
		this.gl = this.canvas.getContext('webgl2');

		if (!this.gl) {
			console.error('WebGL 2 not supported');
			throw 'WebGL 2 not supported';
		}

		this.programs = {
			box: new BoxProgram(this.gl),
			glyph: new GlyphProgram(this.gl),
			layer: new LayerProgram(this.gl),
			stream: new StreamProgram(this.gl),
			text: new TextProgram(this.gl),
		}

		//this.gl.enable(this.gl.DEPTH_TEST);
		//this.gl.disable(this.gl.BLEND);
		//this.gl.blendFunc(this.gl.SRC_ALPHA, this.gl.ONE);
		//this.gl.pixelStorei(this.gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
		//this.gl.blendFuncSeparate(this.gl.SRC_ALPHA, this.gl.ONE_MINUS_SRC_ALPHA, this.gl.ONE, this.gl.ONE_MINUS_SRC_ALPHA);
	}

	resize(x, y) {
		this.canvas.width = x;
		this.canvas.height = y;

		this.gl.viewport(0, 0, this.gl.canvas.width, this.gl.canvas.height);
		//setup for each of existing scenes
		for (let scene of this.scenes){
			scene.screen(this.canvas.width, this.canvas.height);
		}
	}

	render(){
		if (this.scene !== null){
			this.scene.render();
		}
	}

	addScene(sceneContents, ui){
		let scene = new Scene(this.gl);
		scene.init(sceneContents, ui, this.programs);
		this.scenes.push(scene);

		if (this.scene === null){
			this.scene = scene;
			scene.screen(this.canvas.width, this.canvas.height);
		}
	}

	displayScene(index){
		console.log('scene', index);
		this.scene = this.scenes[index];
		this.scene.screen(this.canvas.width, this.canvas.height);
	}

	delete(){
		//Delete all of the scenes...
		for (let scene of this.scenes){
			scene.delete();
		}
		
		this.scene = null
		this.scenes = [];
	}


	rotate(dx, dy){
		if (this.scene){
			this.scene.camera.rotate(dx, dy);
		}
	}

	moveFront(d){
		if (this.scene){
			this.scene.camera.moveFront(d);
		}
	}

	moveBack(d){
		if (this.scene){
			this.scene.camera.moveBack(d);
		}
	}
} 

class Interface {
    constructor(app) {
        this.app = app;
        this.keys = {};
        this.mouse = {
            x: null,
            y: null,
            down: false,
        };
    }

    onKeyDown(key) {
        this.keys[key] = true;
        this.app.pressed(key);
        console.log(key);
    }

    onKeyUp(key){
        this.keys[key] = false;
    }

    onMouseDown(x, y) {
        this.mouse.down = true;
        this.mouse.x = x;
        this.mouse.y = y;
    };

    onMouseUp(x, y) {
        this.mouse.down = false;
    };

    onMouseMove(x, y) {
        if (!this.mouse.down) {
            return;
        }

        let delta_x = x - this.mouse.x;
        let delta_y = y - this.mouse.y;

        this.mouse.x = x
        this.mouse.y = y;

        this.app.graphics.rotate(delta_x, delta_y);
    };

    wheel(delta){
        if (delta > 0)
            this.app.graphics.moveFront(delta);
		else
            this.app.graphics.moveBack(-delta);
    }
}function sum(array) {
    var num = 0;
    for (var i = 0, l = array.length; i < l; i++) num += array[i];
    return num;
};

function mean(array) {
    return sum(array) / array.length;
};

function variance(array) {
    var m = mean(array);
    return mean(array.map(function(num) {
        return Math.pow(num - m, 2);
    }));
};

function standardDeviation(array) {
    return Math.sqrt(variance(array));
};

function meanAbsoluteDeviation(array) {
    var m = mean(array);
    return mean(array.map(function(num) {
        return Math.abs(num - m);
    }));
};

function median(array) {
    array.sort();
    let half = Math.floor(array.length/2);
    if(array.length % 2)
        return array[half];
    else
        return (array[half-1] + array[half]) / 2.0;
}

function max(array) {
    array.sort();
    return array[array.length - 1];
} 

class FieldUI{
    constructor(key, data){
        this.key = key;
        this.data = data;
        this.selected = false;
    }

    select(){
        this.element.classList.add('selected');
        this.selected = true;
    }

    deselect(){
        this.element.classList.remove('selected');
        this.selected = false;
    }

    next(){

    }

    previous(){

    }
}

class DisplayFieldUI extends FieldUI{
    get node() {
        let fdom = document.createElement('div');
        fdom.classList.add('field');
        this.element = fdom;

        let title = document.createElement('div');
        title.classList.add('title');
        title.innerHTML = this.key;
        this.element.appendChild(title);

        let display = document.createElement('div');
        display.classList.add('value');
        display.innerHTML = this.data.value;
        this.element.appendChild(display);
        return this.element;
    }
}


class SelectFieldUI extends FieldUI{
    get node() {
        let fdom = document.createElement('div');
        fdom.classList.add('field');
        this.element = fdom;

        let title = document.createElement('div');
        title.classList.add('title');
        title.innerHTML = this.key;
        this.element.appendChild(title);

        let display = document.createElement('div');
        display.classList.add('value');
        display.innerHTML = this.data.value;
        this.display = display;
        this.element.appendChild(display);

        let active = this.data.options.indexOf(this.data.value);
        this.activeOption = active;

        return this.element;
    }

    next(){
        this.activeOption = (this.activeOption + 1) % this.data.options.length;
        this.display.innerHTML = this.data.options[this.activeOption];
        this.data.callbacks[this.activeOption]();
    }

    previous(){
        this.activeOption = (this.activeOption - 1 + this.data.options.length) % this.data.options.length;
        this.display.innerHTML = this.data.options[this.activeOption];
        this.data.callbacks[this.activeOption]();
    }
}

class SliderFieldUI extends FieldUI{
    get node() {
        let fdom = document.createElement('div');
        fdom.classList.add('field');
        this.element = fdom;

        let title = document.createElement('div');
        title.classList.add('title');
        title.innerHTML = this.key;
        this.element.appendChild(title);

        let display = document.createElement('div');
        display.classList.add('value');
        display.innerHTML = this.data.value;
        this.display = display;
        this.element.appendChild(display);

        this.value = this.data.value;
        return this.element;
    }

    next(alternative){
        let delta = alternative ? this.data.delta * 10 : this.data.delta;
        this.value = Math.min(this.value + delta, this.data.max);
        this.display.innerHTML = this.value.toFixed(3);
        this.data.callback(this.value);
    }

    previous(alternative){
        let delta = alternative ? this.data.delta * 10 : this.data.delta;
        this.value = Math.max(this.value - delta, this.data.min);
        this.display.innerHTML = this.value.toFixed(3);
        this.data.callback(this.value);
    }
} 

class WidgetUI {
    constructor(data){
        this.data = data;
        this.fieldElements = [];
        this.selected = 0;
    }

    get node() {
        this.fieldElements = [];

        let widget = document.createElement('div');
        widget.classList.add('widget');

        for (let field in this.data){
            ///display field
            if (this.data[field].type === 'display'){
                let f = new DisplayFieldUI(field, this.data[field]);
                widget.appendChild(f.node);
                this.fieldElements.push(f);
            }
            ///select field
            else if (this.data[field].type === 'select'){
                let f = new SelectFieldUI(field, this.data[field]);
                widget.appendChild(f.node);
                this.fieldElements.push(f);
            }
            ///slider field
            else if (this.data[field].type === 'slider'){
                let f = new SliderFieldUI(field, this.data[field]);
                widget.appendChild(f.node);
                this.fieldElements.push(f);
            }
        }

        widget.style.display = 'none';
        this.element = widget;
        return widget;
    }

    get nodenavpoint(){
        let navpoint = document.createElement('div');
        navpoint.classList.add('navpoint');
        this.navpoint = navpoint;
        return navpoint;
    }
    
    select(index){
        this.element.style.display = 'block';
        this.navpoint.classList.add('selected');
        this.fieldElements[this.selected].deselect();
        index = (index + this.fieldElements.length) % this.fieldElements.length;  
        this.fieldElements[index].select();
        this.selected = index;
    }

    selectLastField(){
        this.select(this.fieldElements.length - 1);
    }

    selectFirstField(){
        this.select(0);
    }
    
    deselect(){
        this.element.style.display = 'none';
        this.navpoint.classList.remove('selected');
        this.fieldElements[this.selected].deselect();
    }

    nextField(){
        this.select(this.selected + 1);
    }

    previousField(){
        this.select(this.selected - 1);
    }

    get firstFieldSelected(){
        return this.selected === 0;
    }

    get lastFieldSelected(){
        return this.selected === this.fieldElements.length - 1;
    }

    nextValue(alternative){
        this.fieldElements[this.selected].next(alternative);
    }

    previousValue(alternative){
        this.fieldElements[this.selected].previous(alternative);
    }
} 

class SceneUI {
    constructor(){
        this.widgets = [];
        this.selected = 0;
    }


    addWidget(widget){
        this.widgets.push(widget);
    }

    get node() {
        let scene = document.createElement('div');
        scene.id = 'scene';

        //widgets
        let scenew = document.createElement('div');
        scenew.id = 'scenewidgets';

        let up = document.createElement('img');
        up.src = DataManager.getIcon('up.svg');
        up.classList.add('widgetnav');
        up.classList.add('canvasIcon');
        let down = document.createElement('img');
        down.src = DataManager.getIcon('down.svg');
        down.classList.add('widgetnav');
        down.classList.add('canvasIcon');

        scenew.appendChild(up);
        for (let w of this.widgets){
            scenew.appendChild(w.node);
        }
        scenew.appendChild(down);
        scene.appendChild(scenew);

        //navpoints
        let scenen = document.createElement('div');
        scenen.id = 'scenenavpoints';
        for (let w of this.widgets){
            scenen.appendChild(w.nodenavpoint);
        }
        scene.appendChild(scenen);

        return scene;
    }

    select(indexW, indexF){
        if (this.widgets.length <= indexW)
            return;

        this.selected = indexW;
        this.widgets[this.selected].select(indexF);
    }

    selectFirstField(){
        this.widgets[this.selected].selectFirstField();
    }

    selectLastField(){
        this.widgets[this.selected].selectLastField();
    }

    nextWidget(){
        this.widgets[this.selected].deselect();
        this.selected = (this.selected + 1) % this.widgets.length;
        this.widgets[this.selected].select(0);
    }

    previousWidget(){
        this.widgets[this.selected].deselect();
        this.selected = (this.selected - 1 + this.widgets.length) % this.widgets.length;
        this.widgets[this.selected].select(0);
    }

    get lastFieldSelected() {
        return this.widgets[this.selected].lastFieldSelected;
    }

    get firstFieldSelected() {
        return this.widgets[this.selected].firstFieldSelected;
    }

    nextField(){
        this.widgets[this.selected].nextField();
    }

    previousField(){
        this.widgets[this.selected].previousField();
    }

    nextValue(alternative){
        this.widgets[this.selected].nextValue(alternative);
    }

    previousValue(alternative){
        this.widgets[this.selected].previousValue(alternative);
    }
} 


class FlowAppUI {
    constructor(canvas){
        this.canvas = canvas;
        let parent = canvas.parentNode;

        let placeholder = document.createElement('div');
        placeholder.id = 'placeholderui';
        placeholder.innerHTML = 'M';
        parent.appendChild(placeholder);

        
        let element = document.createElement('div');
        element.id = 'flowappui';
        parent.appendChild(element);
        element.style.display = 'none';

        //scenes label
        let sceneLabel = document.createElement('div');
        sceneLabel.id = 'sceneLabel';
        sceneLabel.innerHTML = 'scenes';
        sceneLabel.classList.add('menuLabel');
        element.appendChild(sceneLabel);

        // scenes nav description
        let sceneDesc = document.createElement('div');
        sceneDesc.id = 'sceneNavDesc';
        sceneDesc.innerHTML = 'shift + arrows to move, enter to select';
        sceneDesc.classList.add('menuLabel');
        sceneDesc.classList.add('menuDescription');
        element.appendChild(sceneDesc);

        let sceneListContainer = document.createElement('div');
        sceneListContainer.id = 'sceneListContainer';
        element.appendChild(sceneListContainer);

        //nav
        let sceneListLeft = document.createElement('img');
        sceneListLeft.id = 'sceneListLeft';
        sceneListLeft.src = DataManager.getIcon('left.svg');
        sceneListLeft.classList.add('canvasIcon');
        sceneListLeft.classList.add('side');
        sceneListContainer.appendChild(sceneListLeft);
        
        //list
        let sceneList = document.createElement('div');
        sceneList.id = 'sceneList';
        sceneListContainer.appendChild(sceneList);

        //nav
        let sceneListRight = document.createElement('img');
        sceneListRight.id = 'sceneListRight';
        sceneListRight.src = DataManager.getIcon('right.svg');
        sceneListRight.classList.add('canvasIcon');
        sceneListRight.classList.add('side');
        sceneListContainer.appendChild(sceneListRight);

        //elements label
        let elementsLabel = document.createElement('div');
        elementsLabel.id = 'sceneLabel';
        elementsLabel.innerHTML = 'scene elements';
        elementsLabel.classList.add('menuLabel');
        element.appendChild(elementsLabel);

        //elements nav description
        let elementsDesc = document.createElement('div');
        elementsDesc.id = 'sceneNavDesc';
        elementsDesc.innerHTML = 'up/down arrows to move, left/right to change';
        elementsDesc.classList.add('menuLabel');
        elementsDesc.classList.add('menuDescription');
        element.appendChild(elementsDesc);

        let sceneElement = document.createElement('div');
        sceneElement.id = 'sceneElement';
        element.appendChild(sceneElement);
        
        this.placeholder = placeholder;
        this.element = element;
        this.sceneList = sceneList;
        this.sceneElement = sceneElement;
        
        this.scenes = [];
        this.selectedScene = 0;
        this.active = 0;

        this.menuVisible = false;
    }

    addScene(scene){
        this.scenes.push(scene);

        let sceneCard = document.createElement('div');
        sceneCard.id = 'scene' + (this.scenes.length - 1);
        sceneCard.classList.add('scene');
        this.sceneList.appendChild(sceneCard);
    }

    displayScene(index){
        while (this.sceneElement.firstChild) {
            this.sceneElement.removeChild(this.sceneElement.firstChild);
        }

        this.active = index;
        this.selectedScene = index;

        let ui = this.scenes[this.active].node;
        this.sceneElement.appendChild(ui);

        this.scenes[this.active].select(0, 0);
        
        let scene = document.getElementById('scene' + this.selectedScene);
        scene.classList.add('selected');
    }

    nextScene(){
        if (!this.menuVisible)
            return;

        let scene = document.getElementById('scene' + this.selectedScene);
        scene.classList.remove('selected');

        this.selectedScene = (this.selectedScene + 1) % this.scenes.length;

        scene = document.getElementById('scene' + this.selectedScene);
        scene.classList.add('selected');
    }

    previousScene(){
        if (!this.menuVisible)
            return;

        let scene = document.getElementById('scene' + this.selectedScene);
        scene.classList.remove('selected');

        this.selectedScene = (this.selectedScene - 1 + this.scenes.length) % this.scenes.length;

        scene = document.getElementById('scene' + this.selectedScene);
        scene.classList.add('selected');
    }

    nextWidget(){
        if (!this.menuVisible)
            return;

        this.scenes[this.active].nextWidget();
    }

    previousWidget(){
        if (!this.menuVisible)
            return;

        this.scenes[this.active].previousWidget();
    }

    nextField(){
        if (!this.menuVisible)
            return;

        if (this.scenes[this.active].lastFieldSelected){
            this.scenes[this.active].nextWidget();
            this.scenes[this.active].selectFirstField();
        } else {
            this.scenes[this.active].nextField();
        }
    }

    previousField(){
        if (!this.menuVisible)
            return;

        if (this.scenes[this.active].firstFieldSelected){
            this.scenes[this.active].previousWidget();
            this.scenes[this.active].selectLastField();
        } else {
            this.scenes[this.active].previousField();
        }
    }

    nextValue(alternative){
        if (!this.menuVisible)
            return;

        this.scenes[this.active].nextValue(alternative);
    }

    previousValue(alternative){
        if (!this.menuVisible)
            return;

        this.scenes[this.active].previousValue(alternative);
    }

    toggleMenu(){
        if (this.menuVisible){
            this.element.style.display = 'none';
            this.placeholder.style.display = 'block';
            this.menuVisible = false;
        } else {
            this.element.style.display = 'block';
            this.placeholder.style.display = 'none';
            this.menuVisible = true;
        }

    }

    delete(){
        while (this.sceneElement.firstChild) {
            this.sceneElement.removeChild(this.sceneElement.firstChild);
        }

        while (this.sceneList.firstChild) {
            this.sceneList.removeChild(this.sceneList.firstChild);
        }

        this.scenes = [];
    }

    resize(x, y){
        this.element.style.fontSize = (((y / 1400) - 1) + 1) + 'em';
        this.element.style.width = (((y / 1400) - 1) * 400 + 400) + 'px';
    }
} 

class FlowApp {
    constructor(canvas) {
        this.canvas = canvas;
        this.interface = new Interface(this);
        this.graphics = new Graphics(canvas);
        this.ui = new FlowAppUI(canvas);
    }

    init(key) {
        this.key = key;
        this.graphics.init();
    }

    load(contents){
        //delete all previously allocated buffers and data etc.
        this.graphics.delete();
        this.ui.delete();

        //allocate new scenes
        for (let scene_id in contents) {
            console.log('loading scene', scene_id);
            this.graphics.addScene(contents[scene_id], this.ui);
        }

        //none was allocated so has to be first scene
		this.ui.displayScene(0); //zero as first scene
    }

    render() {
        this.graphics.render();

        if (this.interface.keys[84]){
            this.graphics.scene.camera.setPosition(CameraPosition.top);
        }
        if (this.interface.keys[70]){
            this.graphics.scene.camera.setPosition(CameraPosition.front);
        }
        if (this.interface.keys[82]){
            this.graphics.scene.camera.setPosition(CameraPosition.side);
        }

        if (this.interface.keys[87]){
            if (this.interface.keys[16]){
                this.graphics.scene.camera.setPosition(CameraPosition.moveUp);
            } else {
                this.graphics.scene.camera.setPosition(CameraPosition.rotateUp);
            }
        }
        if (this.interface.keys[83]){
            if (this.interface.keys[16]){
                this.graphics.scene.camera.setPosition(CameraPosition.moveDown);
            } else {
                this.graphics.scene.camera.setPosition(CameraPosition.rotateDown);
            }
        }

        if (this.interface.keys[68]){
            if (this.interface.keys[16]){
                this.graphics.scene.camera.moveRight();
            } else {
                this.graphics.scene.camera.setPosition(CameraPosition.rotateRight);
            }
        }
        if (this.interface.keys[65]){
            if (this.interface.keys[16]){
                this.graphics.scene.camera.moveLeft();
            } else {
                this.graphics.scene.camera.setPosition(CameraPosition.rotateLeft);
            }
        }

        if (this.interface.keys[72]){
            this.graphics.scene.camera.setPosition(CameraPosition.origin);
        }
    }

    resize(x, y){
        this.graphics.resize(x, y);
        this.ui.resize(x, y);
    }

    pressed(key){
        if (key === 40){
            //16 = shift 
            if (this.interface.keys[16]){
                this.ui.nextWidget();
            } else {
                this.ui.nextField();
            }
        }

        if (key === 38){
            //16 = shift 
            if (this.interface.keys[16]){
                this.ui.previousWidget();
            } else {
                this.ui.previousField();
            }
        }

        if (key === 39){
            //16 = shift 
            if (this.interface.keys[16]){
                this.ui.nextScene();
            } else {
                //parameter if alt is pressed
                this.ui.nextValue(this.interface.keys[225]);
            }
        }

        if (key === 37){
            //16 = shift 
            if (this.interface.keys[16]){
                this.ui.previousScene();
            } else {
                this.ui.previousValue(this.interface.keys[225]);
            }
        }

        if (key === 13){
            let sceneId = this.ui.selectedScene;
            this.graphics.displayScene(sceneId);
            this.ui.displayScene(sceneId);
        }

        if (key === 77){
            this.ui.toggleMenu();
        }

        if (key === 80){
            this.graphics.scene.camera.toggleMode();
        }
    }

    
}
